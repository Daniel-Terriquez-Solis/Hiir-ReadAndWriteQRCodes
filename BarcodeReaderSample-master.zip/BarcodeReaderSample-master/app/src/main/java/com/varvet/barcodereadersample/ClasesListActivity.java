package com.varvet.barcodereadersample;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.net.Inet4Address;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ClasesListActivity extends AppCompatActivity {

    ListView lv;
    TextView txtNombreMaestro, txtClaseActual;
    Button btnQR;

    Usuario maestro;
    Intent intent;
    Persistencia persistencia;
    List<Clase> clases;
    Clase claseActual;
    int currentHour;

    ClasesMaestro cm = new ClasesMaestro();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clases_list);

        lv = (ListView) findViewById(R.id.idListView);
        txtNombreMaestro = (TextView) findViewById(R.id.idNombreMaestro);
        txtClaseActual = (TextView) findViewById(R.id.idClaseActual);
        btnQR = (Button) findViewById(R.id.idBtnQR);

        persistencia = new Persistencia();
        intent = getIntent();
        maestro = (Usuario) intent.getSerializableExtra("maestro");
        cm.execute(maestro.getId());

        txtNombreMaestro.setText(maestro.getNombre());
        Calendar calendar = Calendar.getInstance();
        currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        for(int i = 0; i<clases.size();i++){
            if (currentHour==claseActual.getHourStart()){
                claseActual = clases.get(i);
            }
        }
        txtClaseActual.setText(claseActual.getName()+" "+claseActual.getHourStart()+":00 - "+claseActual.getHourEnd()+":00");

        btnQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClasesListActivity.this, GenQR.class);
                intent.putExtra("ID", String.valueOf(claseActual.getId()));
                startActivity(intent);
            }
        });

        BaseAdapter adapter = new AdapterClase(clases, this);

        lv.setAdapter(adapter);
    }

    private class ClasesMaestro extends AsyncTask<Integer, Void, List<Clase>> {
        @Override
        protected List<Clase> doInBackground(Integer... id_maestro) {
            int id = Integer.parseInt(id_maestro.toString());
            return persistencia.obtenerClasesDeMaestro(id);
        }

        @Override
        protected void onPostExecute(List<Clase> clasesObtenidas) { clases = clasesObtenidas;
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }
}