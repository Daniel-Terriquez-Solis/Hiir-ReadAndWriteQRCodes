package com.varvet.barcodereadersample

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.Button
import android.widget.TextView
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.vision.barcode.Barcode
import com.varvet.barcodereadersample.barcode.BarcodeCaptureActivity

class MainActivity : AppCompatActivity() {

    private lateinit var mResultTextView: TextView
    private lateinit var mTextoResultado: TextView
    var alumno:Usuario = Usuario()
    var id_alumno:Int = 0
    var ba:BuscarAlumno = BuscarAlumno()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        id_alumno = intent.getIntExtra("id_alumno", -1)
        ba.execute(id_alumno)
        if(id_alumno == -1){
            val login = Intent(applicationContext, Login::class.java)
            startActivity(login)
        }

        mResultTextView = findViewById(R.id.result_textview)
        mTextoResultado = findViewById(R.id.idtxtResultado)

        findViewById<Button>(R.id.scan_barcode_button).setOnClickListener {
            val intent = Intent(applicationContext, BarcodeCaptureActivity::class.java)
            startActivityForResult(intent, BARCODE_READER_REQUEST_CODE)
        }

        mResultTextView.setText(alumno.getNombre())
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == BARCODE_READER_REQUEST_CODE) {
            if (resultCode == CommonStatusCodes.SUCCESS) {
                if (data != null) {
                    val barcode = data.getParcelableExtra<Barcode>(BarcodeCaptureActivity.BarcodeObject)
                    val p = barcode.cornerPoints
                    mTextoResultado.setText(barcode.displayValue);
                    mResultTextView.text = "Bienvenido "+alumno.getNombre()+", se ha registrado con exito la asistencia";
                } else
                    mResultTextView.setText(R.string.no_barcode_captured)
            } else
                Log.e(LOG_TAG, String.format(getString(R.string.barcode_error_format),
                        CommonStatusCodes.getStatusCodeString(resultCode)))
        } else
            super.onActivityResult(requestCode, resultCode, data)
    }

    companion object {
        private val LOG_TAG = MainActivity::class.java.simpleName
        private val BARCODE_READER_REQUEST_CODE = 1
    }

    class BuscarAlumno() : AsyncTask<Int, Void, Usuario>() {
        override fun doInBackground(vararg params: Int?): Usuario? {
            val persistencia:Persistencia = Persistencia()
            val id:Int = params[0].toString().toInt()
            return persistencia.buscarAlumnoPorId(id)
        }

        override fun onPreExecute() {
            super.onPreExecute()
            // ...
        }

        override fun onPostExecute(result: Usuario?) {
            super.onPostExecute(result)
            // ...
        }
    }
}
